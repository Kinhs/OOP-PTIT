package J04005;

public class ThiSinh {
    public String name, dob;
    public double p1, p2, p3;

    public ThiSinh(String name,String dob, double p1, double p2, double p3) {
        this.name = name;
        this.dob = dob;
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }

    public String toString() {
        return name + " " + dob;
    }

    public double sump() {
        return p1 + p2 + p3;
    }
}
