package J04005;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String dob = sc.nextLine();
        double p1 = sc.nextDouble();
        double p2 = sc.nextDouble();
        double p3 = sc.nextDouble();
        ThiSinh thiSinh = new ThiSinh(name, dob, p1, p2, p3);
        System.out.printf("%s %.1f", thiSinh.toString(), thiSinh.sump());
    }
}
