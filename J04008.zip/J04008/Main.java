package J04008;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while (t-- > 0) {
            Point p1 = new Point(sc.nextDouble(), sc.nextDouble());
            Point p2 = new Point(sc.nextDouble(), sc.nextDouble());
            Point p3 = new Point(sc.nextDouble(), sc.nextDouble());
            double a = Point.distance(p1, p2);
            double b = Point.distance(p2, p3);
            double c = Point.distance(p3, p1);
            if (a < b+c && b < c+a && c < a+b) {
                System.out.printf("%.3f\n", a+b+c);
            } else {
                System.out.println("INVALID");
            }
        }
    }
}
