package J04015;

public class Teacher {
    public String id, name;
    int base_salary, co_salary, salary, allowance;

    public Teacher(String id, String name, int base_salary) {
        this.id = id;
        this.name = name;
        this.base_salary = base_salary;
        co_salary = Integer.parseInt(id.substring(2));
        if (id.startsWith("HT")) allowance = 2000000;
        else if (id.startsWith("HP")) allowance = 900000;
        else allowance = 500000;
        salary = base_salary*co_salary + allowance;
    }

    public String toString() {
        return id + " " + name + " " + co_salary + " " + allowance + " " + salary;
    }
}
