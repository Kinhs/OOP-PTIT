package J04002;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double a = sc.nextDouble(), b = sc.nextDouble();
        String c = sc.next();
        if (a <= 0 || b <= 0 || a % 1 != 0 || b % 1 != 0) {
            System.out.print("INVALID");
        } else {
            Rectange r = new Rectange(a, b, c);
            System.out.printf("%.0f %.0f %s", r.findPerimeter(), r.findArea(), r.getColor());
        }
    }
}
