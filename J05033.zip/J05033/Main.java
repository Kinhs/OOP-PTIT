package J05033;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Time[] t = new Time[n];
        for (int i = 0; i < n; i++) {
            t[i] = new Time(sc.nextInt(), sc.nextInt(), sc.nextInt());
        }
        for (int i = 0; i < n-1; i++) {
            for (int j = i+1; j < n; j++) {
                if (t[i].greaterThan(t[j])) {
                    Time tmp = t[i];
                    t[i] = t[j];
                    t[j] = tmp;
                }
            }
        }
        for (int i = 0; i < n; i++) {
            System.out.println(t[i]);
        }
    }
}
