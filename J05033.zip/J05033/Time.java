package J05033;

public class Time {
    public int hour, minute, second, total;
    public Time(int hour, int minute, int second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
        total = hour*3600 + minute*60 + second;
    }

    public boolean greaterThan(Time t) {
        return total > t.total;
    }

    public String toString() {
        return hour + " " + minute + " " + second;
    }
}
