package J04001;

import java.lang.Math.*;

public class Point {
    private double x, y;
    public Point(){

    }
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }
    public Point(Point p) {
        x = p.x;
        y = p.y;
    }
    public double getX() {
        return x;
    }
    public double getY() {
        return y;
    }
    public double distance(Point secondPoint) {
        return Math.sqrt((x-secondPoint.x)*(x-secondPoint.x) + (y-secondPoint.y)*(y-secondPoint.y));
    }
    public static double distance(Point p1, Point p2) {
        return Math.sqrt((p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y));
    }
    public String toString() {
        return "("+x+","+y+")";
    }
}
