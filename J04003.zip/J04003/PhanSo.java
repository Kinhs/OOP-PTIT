/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J04003;
import java.util.*;

/**
 *
 * @author trong
 */
public class PhanSo {
    private long ts, ms;
    
    public PhanSo(long ts, long ms) {
        this.ts = ts;
        this.ms = ms;
    }
    
    public String toString() {
        return ts+"/"+ms;
    }
    
    public void rutgon() {
        long mindivisor = gcd(ts, ms);
        ts /= mindivisor;
        ms /= mindivisor;
    }
    
    public long gcd(long a, long b) {
        if (b == 0) return a;
        return gcd(b, a%b);
    }
    
}
