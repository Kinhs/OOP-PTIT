package J04006;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String classId = sc.nextLine();
        String dob = sc.nextLine();
        double gpa = sc.nextDouble();
        Student student = new Student(name, classId, dob, gpa);
        student.prt();
    }
}
