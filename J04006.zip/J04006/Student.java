package J04006;

public class Student {
    public String name, dob, id, classId;
    public double gpa;

    public Student(String name, String classId, String dob, double gpa) {
        this.name = name;
        this.classId = classId;
        this.gpa = gpa;
        this.id = "B20DCCN001";
        StringBuilder tmp = new StringBuilder(dob);
        if (tmp.charAt(1) == '/') tmp.insert(0,'0');
        if (tmp.charAt(4) == '/') tmp.insert(3, '0');
        this.dob = tmp.toString();
    }

    public void prt() {
        System.out.printf("%s %s %s %s %.2f", id, name, classId, dob, gpa);
    }
}
