package J04007;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine(),
               b = sc.nextLine(),
               c = sc.nextLine(),
               d = sc.nextLine(),
               e = sc.nextLine(),
               f = sc.nextLine();
        NhanVien nhanVien = new NhanVien(a, b, c, d, e, f);
        nhanVien.prt();
    }
}
