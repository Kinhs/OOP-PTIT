package J04007;

public class NhanVien {
    public String id, name, gender, dob, address, tax, signdate;

    public NhanVien(String name, String gender, String dob, String address, String tax, String signdate) {
        id = "00001";
        this.name = name;
        this.gender = gender;
        this.dob = dob;
        this.address = address;
        this.tax = tax;
        this.signdate = signdate;
    }

    public void prt() {
        System.out.printf("%s %s %s %s %s %s %s", id, name, gender, dob, address, tax, signdate);
    }
}
